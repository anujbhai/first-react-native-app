import React, { useState } from "react";
import { Button, StyleSheet, Text, View } from "react-native";

const CounterScreen = () => {
    const [ count, setCount ] = useState(0);

    return (
        <View>
            <Button
                title="Increase"
                onPress={ () => {
                    setCount(count + 1);
                } }
            />
            <Button
                title="Decrease"
                onPress={ () => {
                    // Prevent counter to go below zero
                    count === 0 ? setCount(count) : setCount(count - 1);
                } }
            />
            <Text>Current Count: { count }</Text>
        </View>
    );
};

const styles = StyleSheet.create({

});

export default CounterScreen;
