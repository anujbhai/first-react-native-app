import React from "react";
import { Text, StyleSheet, View, Button, TouchableOpacity } from "react-native";

const HomeScreen = ({ navigation }) => {
  return (
    <View>
      <Text style={ styles.text }>HomeScreen</Text>
      <Button
        onPress={ () => navigation.navigate("Components") }
        title="Go to components demo"
      />
      <TouchableOpacity onPress={ () => navigation.navigate("List") }>
        <Text>Go to list demo</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={ () => navigation.navigate("Image") }>
        <Text>Go to images demo</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={ () => navigation.navigate("Counter") }>
        <Text>Go to Counter</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={ () => navigation.navigate("Color") }>
        <Text>Go to Color Changer</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={ () => navigation.navigate("ColorAdjustor") }>
        <Text>Go to Color Color Adjustor</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  text: {
    fontSize: 30
  },
  button: {
    marginVertical: 15,
    textAlign: "center"
  }
});

export default HomeScreen;
