import React from "react";
import { Text, StyleSheet, View } from "react-native";

const ComponentsScreen = () => {
// props
  const username = "Anuj Upadhyay";

  return (
    <View style={ styles.wrapper }>
      <Text style={ styles.textStyle1 }>Getting started with React Native.</Text>
      <Text style={ styles.textStyle2 }>My name is { username }</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    padding: 15
  },
  textStyle1: {
    fontSize: 45
  },
  textStyle2: {
    fontSize: 20
  }
});

export default ComponentsScreen;
